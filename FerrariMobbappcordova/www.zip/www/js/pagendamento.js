


//Jquery
$(document).ready(function() {

    ListarTodos()
    $("#btnSalvar1").click(function() {
        Salvar();


    });

});



function ListarTodos() {

    $("#tabela > tbody").empty();

    $.ajax({
        url: 'http://10.136.52.25/apiferrariempilhadeiras/api/Agendamento',
        type: 'get',
        dataType: 'json',
        contentType: 'application/json',
        success: function(dados) {
            dados.forEach(function(item) {
                AdicionarLinha(item)

            });
        },
        erro: function(erro) {
            alert('Ocorreu um erro');
        }

    });

}


function AdicionarLinha(item) {

    var novaLinha = $("<tr>")
    var col = ''
    col += '<td>' + item.Nome + '</td>';
    col += '<td>' + item.Visita + '</td>';
    col += '<td>' + item.DTServico + '</td>';
    col += '<td>';
    col += '<button  onclick="AlterarAgendamento(' + item.Id + ')" type="button"'
    col += 'class="btn-small waves-effect waves-light red darken-1">Alterar</button>';
    col += '<button onclick="RemoverLinha(' + item.Id + ')" type="button"'
    col += 'class="btn-small waves-effect waves-light black">Remover</button>';
    col += '</td>';
    novaLinha.append(col);
    $("#tabela").append(novaLinha);

}

//botão incluir Agendamento
$('#AlterarAgendamento').click(function() {

    //resetando o formulário
    $("#formulario").each(function() {
        //limpando o formulario
        this.reset();
    });


    //abre a janela
    $("#confirmacao").openModal()

 
});

//função para botão alterar da tabela
function AlterarAgendamento(id) {
    $.ajax({
        url: 'http://10.136.52.25/apiferrariempilhadeiras/api/Agendamento/' + id,
        type: 'get',
        dataType: 'json',
        contentType: 'application/json',
        success: function(dados) {
            //prenche os dados do cliente na tela
            $('#Id').val(dados.Id);
            $('#nome').val(dados.Nome);
            $('#dtvisita').val(dados.Visita);
            $('#texto').val(dados.DServiço);
            $('#model').val(dados.DsMaquina);
            $('#marc').val(dados.Mmaquina);
            $('#IdUsuario').val(dados.IdUsuario);
            $('#preco').val(dados.VlSeviço);
            $('#dtservico').val(dados.DTServico);
            $('#btnSalvar').text("Salvar");

            //define título do modal de cadastro
            $('#TituloModal').html("Alterar Agendamento")

            //abre a janela
            $("#confirmacao").openModal()

            
        },
        error: function(erro) {
            alert('Ocorreu um erro');
        }
    });
}


function Excluir(id) {

    $.ajax({
        url: 'http://10.136.52.25/apiferrariempilhadeiras/api/Agendamento/' + id,
        type: 'delete',
        contentType: 'application/json',
        success: function (dados) {
            alert('Dados Excluidos com sucesso!');
            ListarTodos()
        },

        error: function (erro) {
            alert('Ocorreu um erro');
        }

    });

}
function RemoverLinha(id) {
    if (confirm("Tem certeza que deseja excluir")) {
        Excluir(id);
    }


}


